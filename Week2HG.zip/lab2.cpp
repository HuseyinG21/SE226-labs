#include <iostream>
using namespace std;

int main() {

    int num;

    cout << "Enter a positive integer greater than 9: ";
    cin >> num;

    while (num <= 9) {
        cout << "Please enter a number greater than 9: ";
        cin >> num;
    }

    int steps = 0;

    cout << num;

    while (num >= 10) {

        int digit_sum = 0;
        int temp = num;

        while (temp > 0) {
            digit_sum += temp % 10;
            temp /= 10;
        }

        num = digit_sum;
        cout << " -> " << num;
        steps++;
    }

    cout << endl;
    cout << "Final Value: " << num << endl;
    cout << "Total Steps: " << steps << endl;

    int n;

    cout << "\nEnter a number between 10 and 100: ";
    cin >> n;

    while (n < 10 || n > 100) {
        cout << "Invalid input. Enter a number between 10 and 100: ";
        cin >> n;
    }

    int fizz = 0, buzz = 0, fizzbuzz = 0;

    for (int i = 1; i <= n; i++) {

        if (i % 7 == 0)
            continue;

        if (i % 3 == 0 && i % 5 == 0) {
            cout << "FizzBuzz" << endl;
            fizzbuzz++;
        }

        else if (i % 3 == 0) {
            cout << "Fizz" << endl;
            fizz++;
        }

        else if (i % 5 == 0) {
            cout << "Buzz" << endl;
            buzz++;
        }

        else {
            cout << i << endl;
        }
    }

    cout << "\nSummary" << endl;
    cout << "Fizz: " << fizz << endl;
    cout << "Buzz: " << buzz << endl;
    cout << "FizzBuzz: " << fizzbuzz << endl;

    int p;

    cout << "\nEnter a number between 3 and 9: ";
    cin >> p;

    while (p < 3 || p > 9) {
        cout << "Invalid input. Enter a number between 3 and 9: ";
        cin >> p;
    }

    for (int i = 1; i <= p; i++) {
        for (int j = 1; j <= i; j++) {
            cout << j;
        }
        cout << endl;
    }

    for (int i = p - 1; i >= 1; i--) {
        for (int j = 1; j <= i; j++) {
            cout << j;
        }
        cout << endl;
    }

    return 0;
}