num = int(input("Enter a positive integer greater than 9: "))

while num <= 9:
    num = int(input("Please enter a number greater than 9: "))

steps = 0
sequence = [num]

while num >= 10:
    digit_sum = 0
    temp = num

    while temp > 0:
        digit_sum += temp % 10
        temp //= 10

    num = digit_sum
    sequence.append(num)
    steps += 1

print(" → ".join(map(str, sequence)))
print("Final Value:", num)
print("Total Steps:", steps)

n = int(input("\nEnter a number between 10 and 100: "))

while n < 10 or n > 100:
    n = int(input("Invalid input. Enter a number between 10 and 100: "))

fizz = 0
buzz = 0
fizzbuzz = 0

for i in range(1, n + 1):

    if i % 7 == 0:
        continue

    if i % 3 == 0 and i % 5 == 0:
        print("FizzBuzz")
        fizzbuzz += 1

    elif i % 3 == 0:
        print("Fizz")
        fizz += 1

    elif i % 5 == 0:
        print("Buzz")
        buzz += 1

    else:
        print(i)

print("\nSummary")
print("Fizz:", fizz)
print("Buzz:", buzz)
print("FizzBuzz:", fizzbuzz)


n = int(input("\nEnter a number between 3 and 9: "))

while n < 3 or n > 9:
    n = int(input("Invalid input. Enter a number between 3 and 9: "))

for i in range(1, n + 1):
    for j in range(1, i + 1):
        print(j, end="")
    print()

for i in range(n - 1, 0, -1):
    for j in range(1, i + 1):
        print(j, end="")
    print()